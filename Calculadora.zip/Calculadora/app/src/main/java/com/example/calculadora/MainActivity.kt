package com.example.calculadora

import android.os.Bundle
import android.view.View
import android.view.View.OnClickListener
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.calculadora.databinding.ActivityMainBinding
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tan

class MainActivity : AppCompatActivity(), OnClickListener{

    private lateinit var binding: ActivityMainBinding

    private var currentInput = ""
    private var operator = ""
    private var firstNumber = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.resultText.text = savedInstanceState?.getString("resultText") ?: "0"

        binding.btnC.setOnClickListener(this)
        binding.btn0.setOnClickListener(this)
        binding.btn1.setOnClickListener(this)
        binding.btn2.setOnClickListener(this)
        binding.btn3.setOnClickListener(this)
        binding.btn4.setOnClickListener(this)
        binding.btn5.setOnClickListener(this)
        binding.btn6.setOnClickListener(this)
        binding.btn7.setOnClickListener(this)
        binding.btn8.setOnClickListener(this)
        binding.btn9.setOnClickListener(this)
        binding.btnAc.setOnClickListener(this)
        binding.btnClosedBracket.setOnClickListener(this)
        binding.btnDivide.setOnClickListener(this)
        binding.btnDot.setOnClickListener(this)
        binding.btnEquals.setOnClickListener(this)
        binding.btnMinus.setOnClickListener(this)
        binding.btnMultiply.setOnClickListener(this)
        binding.btnOpenBracket.setOnClickListener(this)
        binding.btnPlus.setOnClickListener(this)
        binding.resultText.setOnClickListener(this)
        binding.btnCos?.setOnClickListener(this)
        binding.btnSin?.setOnClickListener(this)
        binding.btnTan?.setOnClickListener(this)
        binding.btnX2?.setOnClickListener(this)
        binding.btnX3?.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when(v?.id) {
            binding.btn0.id -> appendToInput("0")
            binding.btn1.id -> appendToInput("1")
            binding.btn2.id -> appendToInput("2")
            binding.btn3.id -> appendToInput("3")
            binding.btn4.id -> appendToInput("4")
            binding.btn5.id -> appendToInput("5")
            binding.btn6.id -> appendToInput("6")
            binding.btn7.id -> appendToInput("7")
            binding.btn8.id -> appendToInput("8")
            binding.btn9.id -> appendToInput("9")
            binding.btnDot.id -> appendToInput(".")
            binding.btnPlus.id -> setOperator("+")
            binding.btnMinus.id -> setOperator("-")
            binding.btnMultiply.id -> setOperator("*")
            binding.btnDivide.id -> setOperator("/")
            binding.btnEquals.id -> calculateResult()
            binding.btnAc.id -> clearInput()
            binding.btnC.id -> clearInput()
            binding.btnCos?.id -> calculateSingleInput { calculateCosInDegrees(currentInput.toDouble()) }
            binding.btnSin?.id -> calculateSingleInput { calculateSinInDegrees(currentInput.toDouble()) }
            binding.btnTan?.id -> calculateSingleInput { calculateTanInDegrees(currentInput.toDouble()) }
            binding.btnX2?.id -> calculateSingleInput { currentInput.toDouble().pow(2) }
            binding.btnX3?.id -> calculateSingleInput { currentInput.toDouble().pow(3) }
        }

    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("resultText", binding.resultText.text.toString())
    }

    private fun appendToInput(value: String) {
        currentInput += value
        binding.resultText.text = currentInput
    }

    private fun setOperator(op: String) {
        if (currentInput.isNotEmpty()) {
            firstNumber = currentInput.toDouble()
            operator = op
            currentInput = ""
            binding.resultText.text = operator
        }
    }

    private fun calculateResult() {
        if (currentInput.isNotEmpty() && operator.isNotEmpty()) {
            val secondNumber = currentInput.toDouble()
            val result = when (operator) {
                "+" -> firstNumber + secondNumber
                "-" -> firstNumber - secondNumber
                "*" -> firstNumber * secondNumber
                "/" -> firstNumber / secondNumber
                else -> 0.0
            }
            binding.resultText.text = result.toString()
            currentInput = result.toString()
            operator = ""
        }
    }
    private fun calculateSingleInput(operation: () -> Double) {
        if (currentInput.isNotEmpty()) {
            val result = operation()
            binding.resultText.text = result.toString()
            currentInput = result.toString()
        }
    }

    private fun calculateTanInDegrees(degrees: Double): Double {
        return if (degrees % 180 == 90.0) {
            Double.NaN
        } else {
            tan(Math.toRadians(degrees))
        }
    }

    private fun calculateCosInDegrees(degrees: Double): Double {
        return cos(Math.toRadians(degrees))
    }

    private fun calculateSinInDegrees(degrees: Double): Double {
        return sin(Math.toRadians(degrees))
    }

    private fun clearInput() {
        currentInput = ""
        operator = ""
        firstNumber = 0.0
        binding.resultText.text = "0"
    }

}